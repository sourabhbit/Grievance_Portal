<?php
//Text Local
//Author: Sourabh Barnwal
//your API Will pe here 
define("API_KEY",'3SJCAhjhOc0-QV0kloFHBfXCVehF7UtP7I6BIqnxV8');
define("MOBILE",'9110086006');

?>