<?php
 $con =mysqli_connect('localhost','root','','grievance') or die(mysqli_error($con));
?>